#pragma once
#include "Mammal.h"

class Dog : public Mammal
{
public:
	Dog();
	virtual ~Dog();
	virtual void move() const;
	virtual void speak() const;

protected:
	int age;
};

