// Lab 13 Part 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Mammal.h"
#include "Dog.h"
#include "Cat.h"
#include "Horse.h"
#include "GuineaPig.h"

using namespace std;

int main()
{
    const int SIZE = 5;
    Mammal* animals[SIZE];
    Mammal* ptr;
    int choice;
    for (int i = 0; i < SIZE; i++)
    {
        cout << "(1)dog (2)cat (3)horse (4)guinea pig: ";
        cin >> choice;
        switch (choice)
        {
        case 1: ptr = new Dog;
            break;
        case 2: ptr = new Cat;
            break;
        case 3: ptr = new Horse;
            break;
        case 4: ptr = new GuineaPig;
            break;
        default: ptr = new Mammal;
            break;
        }
        animals[i] = ptr;
    }

    // Iterate through array, and have each animal speak
    for (int i = 0; i < SIZE; i++)
    {
        animals[i]->speak();
    }

    // Always free dynamically allocated objects
    for (int i = 0; i < SIZE; i++)
    {
        delete animals[i];
    }

    return 0;
}