// Mammal.h
#pragma once
class Mammal
{
public:
    Mammal();
    virtual ~Mammal();
    virtual void move() const;
    virtual void speak() const;

protected:
    int age;
};
