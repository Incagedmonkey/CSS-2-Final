#include "Horse.h"
#include <iostream>

using namespace std;

Horse::Horse() : age(4)
{
	cout << "Horse constructor..." << endl;
}
Horse::~Horse()
{
	cout << "Horse destructor..." << endl;
}
void Horse::move() const
{
	cout << "Horse moves a step!" << endl;
}
void Horse::speak() const
{
	cout << "What does a Horse say? Neigh!" << endl;
}
