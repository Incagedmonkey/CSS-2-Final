#pragma once
#include "Mammal.h"

class Horse : public Mammal
{
public:
	Horse();
	virtual ~Horse();
	virtual void move() const;
	virtual void speak() const;

protected:
	int age;
};

