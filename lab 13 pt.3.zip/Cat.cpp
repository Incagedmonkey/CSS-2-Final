#include "Cat.h"
#include <iostream>

using namespace std;

Cat::Cat() : age(3)
{
	cout << "Cat constructor..." << endl;
}
Cat::~Cat()
{
	cout << "Cat destructor..." << endl;
}
void Cat::move() const
{
	cout << "Cat moves a step!" << endl;
}
void Cat::speak() const
{
	cout << "What does a Cat say? Meow!" << endl;
}
