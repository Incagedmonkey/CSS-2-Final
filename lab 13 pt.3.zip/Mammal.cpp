// Mammal.cpp
#include "Mammal.h"
#include <iostream>

using namespace std;

Mammal::Mammal() : age(1)
{
	cout << "Mammal constructor..." << endl;
}

Mammal::~Mammal()
{
	cout << "Mammal destructor..." << endl;
}

void Mammal::move() const
{
	cout << "Mammal moves a step!" << endl;
}

void Mammal::speak() const
{
	cout << "What does a mammal speak? Mammilian!" << endl;
}