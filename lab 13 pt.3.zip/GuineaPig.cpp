#include "GuineaPig.h"
#include <iostream>

using namespace std;

GuineaPig::GuineaPig() : age(4)
{
	cout << "Guinea Pig constructor..." << endl;
}
GuineaPig::~GuineaPig()
{
	cout << "Guinea Pig destructor..." << endl;
}
void GuineaPig::move() const
{
	cout << "Guinea Pig moves a step!" << endl;
}
void GuineaPig::speak() const
{
	cout << "What does a Guinea Pig say? Wheep Wheep!" << endl;
}
