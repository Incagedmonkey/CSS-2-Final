#include "Dog.h"
#include <iostream>

using namespace std;

Dog::Dog() : age(2)
{
	cout << "Dog constructor..." << endl;
}
Dog::~Dog()
{
	cout << "Dog destructor..." << endl;
}
void Dog::move() const
{
	cout << "Dog moves a step!" << endl;
}
void Dog::speak() const
{
	cout << "What does a dog say? Woof!" << endl;
}
