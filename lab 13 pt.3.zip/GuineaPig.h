#pragma once
#include "Mammal.h"

class GuineaPig : public Mammal
{
public:
	GuineaPig();
	virtual ~GuineaPig();
	virtual void move() const;
	virtual void speak() const;

protected:
	int age;
};