#pragma once
#include "Mammal.h"

class Cat : public Mammal
{
public:
	Cat();
	virtual ~Cat();
	virtual void move() const;
	virtual void speak() const;

protected:
	int age;
};